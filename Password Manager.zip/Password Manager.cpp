#include <iostream>
#include <string>
#include <map>

using namespace std;

class PasswordManager {
private:
    map<string, string> passwords;

public:
    void addPassword(const string& username, const string& password) {
        passwords[username] = password;
    }

    void deletePassword(const string& username) {
        passwords.erase(username);
    }

    string getPassword(const string& username) {
        if (passwords.find(username) != passwords.end()) {
            return passwords[username];
        }
        return "Username not found.";
    }
};

int main() {
    PasswordManager manager;

    manager.addPassword("user1", "password123");
    manager.addPassword("user2", "securePass");

    while (true) {
        cout << "1. Get password" << endl;
        cout << "2. Add new username/password" << endl;
        cout << "3. Delete username/password" << endl;
        cout << "4. Exit" << endl;

        int choice;
        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
            case 1: {
                string username;
                cout << "Enter username: ";
                cin >> username;
                string password = manager.getPassword(username);
                cout << "Password: " << password << endl;
                break;
            }
            case 2: {
                string newUsername, newPassword;
                cout << "Enter new username: ";
                cin >> newUsername;
                cout << "Enter new password: ";
                cin >> newPassword;
                manager.addPassword(newUsername, newPassword);
                cout << "Username/password added." << endl;
                break;
            }
            case 3: {
                string usernameToDelete;
                cout << "Enter username to delete: ";
                cin >> usernameToDelete;
                manager.deletePassword(usernameToDelete);
                cout << "Username/password deleted." << endl;
                break;
            }
            case 4:
                return 0;
            default:
                cout << "Invalid choice. Try again." << endl;
        }
    }

    return 0;
}







































